import paddle
from dove_dataset import DoveDataset
from unet import DoveNet

class SaveBestModel(paddle.callbacks.Callback):
    def __init__(self, target=0.5, path='./best_model', verbose=0):
        self.target = target
        self.epoch = None
        self.path = path

    def on_epoch_end(self, epoch, logs=None):
        self.epoch = epoch

    def on_eval_end(self, logs=None):
        if logs.get('loss')[0] < self.target:
            self.target = logs.get('loss')[0]
            self.model.save(self.path)
            print('best model is loss {} at epoch {}'.format(self.target, self.epoch))

callback_visualdl = paddle.callbacks.VisualDL(log_dir='unet')
callback_savebestmodel = SaveBestModel(target=1, path='unet')
callbacks = [callback_visualdl, callback_savebestmodel]

train_dataset = DoveDataset(mode='train') # 训练数据集
val_dataset = DoveDataset(mode='eval') # 验证数据集

train_loader = paddle.io.DataLoader(train_dataset, places=paddle.CUDAPlace(0), batch_size=32, shuffle=True)

eval_loader = paddle.io.DataLoader(val_dataset, places=paddle.CUDAPlace(0), batch_size= 32)

num_classes = 2
network = DoveNet(num_classes)
model = paddle.Model(network)

optim = paddle.optimizer.Momentum(learning_rate=0.0001, 
                                 momentum=0.9, 
                                 parameters=model.parameters())
model.prepare(optim, paddle.nn.CrossEntropyLoss(axis=1))
model.fit(train_loader, 
          eval_loader, 
          epochs=3, 
          callbacks=callbacks,
          verbose=0)